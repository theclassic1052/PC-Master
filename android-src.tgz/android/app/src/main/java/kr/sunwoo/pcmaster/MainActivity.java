package kr.sunwoo.pcmaster;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

// PC마스터 안드로이드 앱: 웹 화면(GitHub Pages)을 그대로 띄우고,
// 웹이 못 하는 일(연락처 저장·읽기, 파일 공유·저장, 인쇄 등)은 window.PCM 다리로 처리해요.
public class MainActivity extends Activity {
    static final String HOME = "https://theclassic1052.github.io/PC-Master/";
    static final String AUTHORITY = "kr.sunwoo.pcmaster.files";
    static final int REQ_FILE = 11;
    static final int REQ_CONTACTS = 12;
    static final int REQ_AUDIO = 13;

    WebView web;
    Bridge bridge;
    ValueCallback<Uri[]> fileCb;
    Uri camUri;
    String pendingAuth;
    String pendingContactsCb;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.parseColor("#050914"));
        getWindow().setNavigationBarColor(Color.parseColor("#050914"));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050914"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setTextZoom(100);
        // 일반 크롬처럼 보이게 (구글 등에서 앱 내 화면을 막는 경우 대비)
        String ua = s.getUserAgentString().replace("; wv)", ")").replaceAll("Version/\\d+\\.\\d+ ", "");
        s.setUserAgentString(ua + " PCMasterApp/1");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, Collections.emptySet());
        }
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        bridge = new Bridge(this);
        web.addJavascriptInterface(bridge, "PCM");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                return handleUrl(req.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                deliverAuth();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                return openFileChooser(cb, p);
            }

            // target=_blank / window.open → 외부 브라우저로
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        openExternal(r.getUrl());
                        v.destroy();
                        return true;
                    }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        web.setDownloadListener((url, ua2, cd, mime, len) -> {
            if (url.startsWith("http")) openExternal(Uri.parse(url));
        });

        Auto.schedule(this);
        handleIntent(getIntent());
        if (saved != null) web.restoreState(saved);
        else web.loadUrl(HOME);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
        deliverAuth();
    }

    // 크롬 로그인에서 돌아온 경우 (pcmaster://auth?d=...)
    void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri u = intent.getData();
        if (u != null && "pcmaster".equals(u.getScheme())) {
            String d = u.getQueryParameter("d");
            if (d != null) pendingAuth = d;
        }
    }

    void deliverAuth() {
        if (pendingAuth == null || web == null) return;
        String p = pendingAuth;
        web.evaluateJavascript("window.__pcmAuth ? (window.__pcmAuth(" + JSONObject.quote(p) + "), 'ok') : 'wait'", r -> {
            if (r != null && r.contains("ok")) pendingAuth = null;
        });
    }

    String takeAuth() {
        String p = pendingAuth;
        pendingAuth = null;
        return p == null ? "" : p;
    }

    static boolean appHost(String host) {
        if (host == null) return false;
        return host.equals("theclassic1052.github.io")
                || host.endsWith("firebaseapp.com") || host.endsWith(".web.app")
                || host.endsWith("google.com") || host.endsWith("google.co.kr")
                || host.endsWith("googleapis.com") || host.endsWith("gstatic.com")
                || host.endsWith("googleusercontent.com");
    }

    boolean handleUrl(Uri u) {
        String scheme = u.getScheme() == null ? "" : u.getScheme();
        if ((scheme.equals("http") || scheme.equals("https"))) {
            if (appHost(u.getHost())) {
                // 우리 앱 주소 중 "?applogin" 은 크롬에서 열어야 해요
                if (u.getQueryParameter("applogin") != null) { openExternal(u); return true; }
                return false;
            }
            openExternal(u);
            return true;
        }
        if (scheme.equals("intent")) {
            try {
                Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                startActivity(i);
            } catch (Exception e) {
                toast("열 수 있는 앱이 없어요");
            }
            return true;
        }
        if (scheme.equals("pcmaster")) {
            handleIntent(new Intent(Intent.ACTION_VIEW, u));
            deliverAuth();
            return true;
        }
        // tel: sms: mailto: 등
        openExternal(u);
        return true;
    }

    void openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("열 수 있는 앱이 없어요");
        }
    }

    void toast(String m) {
        runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
    }

    // ---- 파일 선택 (사진 · 카메라 · 문서) ----
    boolean openFileChooser(ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams p) {
        if (fileCb != null) fileCb.onReceiveValue(null);
        fileCb = cb;
        boolean image = false;
        String[] types = p.getAcceptTypes();
        if (types == null || types.length == 0 || (types.length == 1 && types[0].isEmpty())) image = true;
        else for (String t : types) if (t.startsWith("image")) image = true;

        Intent pick;
        try { pick = p.createIntent(); } catch (Exception e) { pick = new Intent(Intent.ACTION_GET_CONTENT).setType("*/*"); }
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        if (p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        Intent cam = null;
        camUri = null;
        if (image) {
            try {
                File dir = new File(getCacheDir(), "cam");
                dir.mkdirs();
                File f = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
                camUri = FileProvider.getUriForFile(this, AUTHORITY, f);
                cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                cam.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) { cam = null; camUri = null; }
        }
        Intent chooser;
        if (cam != null && p.isCaptureEnabled()) chooser = cam;
        else {
            chooser = Intent.createChooser(pick, "파일 선택");
            if (cam != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
        }
        try {
            startActivityForResult(chooser, REQ_FILE);
        } catch (Exception e) {
            fileCb.onReceiveValue(null);
            fileCb = null;
            toast("파일 선택 창을 열 수 없어요");
        }
        return true;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || fileCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK) {
            ArrayList<Uri> list = new ArrayList<>();
            if (data != null && data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) list.add(data.getClipData().getItemAt(i).getUri());
            } else if (data != null && data.getData() != null) {
                list.add(data.getData());
            } else if (camUri != null) {
                list.add(camUri);
            }
            if (!list.isEmpty()) out = list.toArray(new Uri[0]);
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
    }

    // ---- 녹음 파일 읽기 권한 (통화 녹음 자동 전송) ----
    void requestAudio() {
        String p = android.os.Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) { Auto.schedule(this); toast("이미 허용되어 있어요"); return; }
        requestPermissions(new String[]{p}, REQ_AUDIO);
    }

    // ---- 연락처 권한 ----
    void withContactsPermission(String cbId) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            bridge.readContacts(cbId);
        } else {
            pendingContactsCb = cbId;
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_AUDIO) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) { Auto.schedule(this); Auto.log(this, "녹음 파일 권한 허용됨"); }
            else toast("녹음 파일 권한이 없으면 통화 녹음을 보낼 수 없어요");
            return;
        }
        if (req == REQ_CONTACTS && pendingContactsCb != null) {
            String cb = pendingContactsCb;
            pendingContactsCb = null;
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) bridge.readContacts(cb);
            else bridge.reply(cb, "{\"error\":\"연락처 권한이 없어요 (설정 → 애플리케이션 → PC마스터 → 권한 → 연락처 허용)\"}");
        }
    }

    // 뒤로가기: 열린 팝업부터 닫고(웹 기록), 더 없으면 앱을 뒤로 보냄
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    void runJs(String js) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    View root() { return web; }
}
