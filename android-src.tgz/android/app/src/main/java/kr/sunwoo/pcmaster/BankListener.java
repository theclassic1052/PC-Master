package kr.sunwoo.pcmaster;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

// 문자 앱 알림 중 은행 입출금 알림만 골라서 서버로 (장부 인입 목록)
public class BankListener extends NotificationListenerService {
    static final List<String> PKGS = Arrays.asList("com.samsung.android.messaging", "com.google.android.apps.messaging", "com.android.mms", "com.android.messaging");
    static final Pattern BANK = Pattern.compile("(?i)(페퍼|농협|NH|새마을|MG|1588-?2100|1599-?9000|062-?384-?6080)");
    static final Pattern MONEY = Pattern.compile("(입금|출금|잔액|이체|원)");
    static final ArrayList<String> recent = new ArrayList<>();

    @Override
    public void onListenerConnected() {
        Auto.log(getApplicationContext(), "은행 문자 알림 읽기 연결됨");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (!PKGS.contains(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            Bundle ex = n.extras;
            String title = cs(ex.getCharSequence(Notification.EXTRA_TITLE));
            String text = cs(ex.getCharSequence(Notification.EXTRA_BIG_TEXT));
            if (text.isEmpty()) text = cs(ex.getCharSequence(Notification.EXTRA_TEXT));
            // 대화형 알림이면 마지막 메시지
            Parcelable[] msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (msgs != null && msgs.length > 0 && msgs[msgs.length - 1] instanceof Bundle) {
                String last = cs(((Bundle) msgs[msgs.length - 1]).getCharSequence("text"));
                if (!last.isEmpty()) text = last;
            }
            if (text.isEmpty()) return;
            if (!BANK.matcher(title + " " + text).find() || !MONEY.matcher(text).find()) return;
            String sig = title + "|" + text;
            synchronized (recent) {
                if (recent.contains(sig)) return;
                recent.add(sig);
                if (recent.size() > 40) recent.remove(0);
            }
            // 앱 화면으로 바로 (서버 확인 없이 장부 인입 목록에 뜸)
            try {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("type", "sms"); o.put("from", title); o.put("text", text); o.put("ts", System.currentTimeMillis());
                Auto.enqueue(getApplicationContext(), o);
            } catch (Exception ignored) { }
            final String from = title, body = text;
            if (Auto.key(getApplicationContext()).isEmpty()) { Auto.log(getApplicationContext(), "서버 암호가 없어 문자를 못 보냈어요"); return; }
            new Thread(() -> Auto.postSms(getApplicationContext(), from, body)).start();
        } catch (Exception e) {
            Auto.log(getApplicationContext(), "문자 알림 처리 오류: " + e.getMessage());
        }
    }

    static String cs(CharSequence c) { return c == null ? "" : c.toString().trim(); }
}
