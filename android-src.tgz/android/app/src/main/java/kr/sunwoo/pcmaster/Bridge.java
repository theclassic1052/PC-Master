package kr.sunwoo.pcmaster;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.Map;

// 웹 화면에서 window.PCM.xxx() 로 부르는 기능들
public class Bridge {
    final MainActivity act;
    WebView printView; // 인쇄 중에 사라지지 않게 잡아둠

    Bridge(MainActivity a) { act = a; }

    @JavascriptInterface
    public String version() { return "1"; }

    @JavascriptInterface
    public void toast(String m) { act.toast(m); }

    @JavascriptInterface
    public String takeAuth() { return act.takeAuth(); }

    @JavascriptInterface
    public void openExternal(String url) {
        act.runOnUiThread(() -> act.openExternal(Uri.parse(url)));
    }

    // 연락처 앱의 "새 연락처" 화면을 이름·전화·주소가 채워진 채로 열기 → 사용자는 저장만 누르면 돼요
    @JavascriptInterface
    public void saveContact(String name, String phone, String address, String email) {
        act.runOnUiThread(() -> {
            try {
                Intent i = new Intent(ContactsContract.Intents.Insert.ACTION);
                i.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                if (name != null && !name.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.NAME, name);
                if (phone != null && !phone.isEmpty()) {
                    i.putExtra(ContactsContract.Intents.Insert.PHONE, phone);
                    i.putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
                }
                if (address != null && !address.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.POSTAL, address);
                if (email != null && !email.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.EMAIL, email);
                i.putExtra("finishActivityOnSaveCompleted", true);
                act.startActivity(i);
            } catch (Exception e) {
                act.toast("연락처 앱을 열 수 없어요: " + e.getMessage());
            }
        });
    }

    // 폰 연락처 전체 읽기 → window.__pcmCb(cbId, json)
    @JavascriptInterface
    public void getContacts(String cbId) {
        act.runOnUiThread(() -> act.withContactsPermission(cbId));
    }

    void readContacts(String cbId) {
        new Thread(() -> {
            try {
                ContentResolver cr = act.getContentResolver();
                Map<Long, JSONObject> map = new LinkedHashMap<>();
                String[] proj = {ContactsContract.Data.CONTACT_ID, ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1};
                String sel = ContactsContract.Data.MIMETYPE + " IN (?,?,?,?)";
                String[] args = {
                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE};
                try (Cursor c = cr.query(ContactsContract.Data.CONTENT_URI, proj, sel, args, ContactsContract.Data.DISPLAY_NAME + " ASC")) {
                    if (c != null) {
                        while (c.moveToNext()) {
                            long id = c.getLong(0);
                            String name = c.getString(1);
                            String mime = c.getString(2);
                            String val = c.getString(3);
                            if (val == null || val.isEmpty()) continue;
                            JSONObject o = map.get(id);
                            if (o == null) {
                                o = new JSONObject();
                                o.put("name", name == null ? "" : name);
                                o.put("tels", new JSONArray());
                                o.put("addr", "");
                                o.put("email", "");
                                o.put("company", "");
                                map.put(id, o);
                            }
                            if (ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE.equals(mime)) o.getJSONArray("tels").put(val);
                            else if (ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE.equals(mime)) { if (o.getString("addr").isEmpty()) o.put("addr", val.replace('\n', ' ')); }
                            else if (ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE.equals(mime)) { if (o.getString("email").isEmpty()) o.put("email", val); }
                            else if (ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE.equals(mime)) { if (o.getString("company").isEmpty()) o.put("company", val); }
                        }
                    }
                }
                JSONArray arr = new JSONArray();
                for (JSONObject o : map.values()) arr.put(o);
                JSONObject res = new JSONObject();
                res.put("list", arr);
                reply(cbId, res.toString());
            } catch (Exception e) {
                reply(cbId, "{\"error\":" + JSONObject.quote("연락처 읽기 실패: " + e.getMessage()) + "}");
            }
        }).start();
    }

    void reply(String cbId, String json) {
        act.runJs("window.__pcmCb && window.__pcmCb(" + JSONObject.quote(cbId) + "," + JSONObject.quote(json) + ")");
    }

    static String safeName(String n) {
        String s = (n == null || n.isEmpty()) ? "file" : n.replaceAll("[\\\\/:*?\"<>|]", "_");
        return s;
    }

    // 파일 공유 (카톡 · 문자 · 메일 등 공유창)
    @JavascriptInterface
    public void shareFile(String b64, String mime, String name, String text) {
        try {
            File dir = new File(act.getCacheDir(), "share");
            dir.mkdirs();
            File f = new File(dir, safeName(name));
            try (OutputStream os = new FileOutputStream(f)) { os.write(Base64.decode(b64, Base64.DEFAULT)); }
            Uri uri = FileProvider.getUriForFile(act, MainActivity.AUTHORITY, f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            i.putExtra(Intent.EXTRA_STREAM, uri);
            if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "보내기");
            act.runOnUiThread(() -> act.startActivity(ch));
        } catch (Exception e) {
            act.toast("공유 실패: " + e.getMessage());
        }
    }

    // 파일 저장 → 폰의 Download/(하위폴더) · 저장된 위치를 돌려줌
    @JavascriptInterface
    public String saveFile(String b64, String mime, String name, String subdir) {
        try {
            String rel = Environment.DIRECTORY_DOWNLOADS + ((subdir == null || subdir.isEmpty()) ? "" : "/" + safeName(subdir));
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(name));
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
            Uri uri = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("저장 위치를 만들 수 없어요");
            try (OutputStream os = act.getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new Exception("파일을 열 수 없어요");
                os.write(Base64.decode(b64, Base64.DEFAULT));
            }
            return rel.replace(Environment.DIRECTORY_DOWNLOADS, "다운로드") + "/" + safeName(name);
        } catch (Exception e) {
            act.toast("저장 실패: " + e.getMessage());
            return "";
        }
    }

    // 인쇄 · PDF 저장 (안드로이드 인쇄 화면)
    @JavascriptInterface
    public void print(String html, String title) {
        act.runOnUiThread(() -> {
            WebView pv = new WebView(act);
            printView = pv;
            pv.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    view.postDelayed(() -> {
                        PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                        String t = (title == null || title.isEmpty()) ? "PC마스터" : title;
                        PrintDocumentAdapter ad = view.createPrintDocumentAdapter(t);
                        pm.print(t, ad, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    }, 500);
                }
            });
            pv.getSettings().setJavaScriptEnabled(false);
            pv.loadDataWithBaseURL(MainActivity.HOME, html, "text/html", "utf-8", null);
        });
    }
}
