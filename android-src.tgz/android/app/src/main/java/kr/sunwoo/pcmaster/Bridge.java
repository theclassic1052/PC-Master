package kr.sunwoo.pcmaster;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.Map;

// 웹 화면에서 window.PCM.xxx() 로 부르는 기능들
public class Bridge {
    final MainActivity act;
    WebView printView; // 인쇄 중에 사라지지 않게 잡아둠

    Bridge(MainActivity a) { act = a; }

    @JavascriptInterface
    public String version() { return "4"; }

    @JavascriptInterface
    public String takePending() { return Auto.takePending(act); }

    @JavascriptInterface
    public void toast(String m) { act.toast(m); }

    // ---- 자동 전송 (Tasker 대신) ----
    @JavascriptInterface
    public void setServerKey(String k) {
        if (k == null) return;
        String old = Auto.key(act);
        if (!k.equals(old)) Auto.prefs(act).edit().putString("key", k).apply();
        Auto.schedule(act);
    }

    @JavascriptInterface
    public String autoStatus() {
        try {
            JSONObject o = new JSONObject();
            o.put("key", !Auto.key(act).isEmpty());
            o.put("audio", Auto.hasAudioPermission(act));
            java.util.Set<String> pk = androidx.core.app.NotificationManagerCompat.getEnabledListenerPackages(act);
            o.put("notif", pk.contains(act.getPackageName()));
            android.os.PowerManager pm = (android.os.PowerManager) act.getSystemService(Context.POWER_SERVICE);
            o.put("battery", pm != null && pm.isIgnoringBatteryOptimizations(act.getPackageName()));
            o.put("log", Auto.prefs(act).getString("log", ""));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    @JavascriptInterface
    public void requestAudioPermission() {
        act.runOnUiThread(() -> act.requestAudio());
    }

    @JavascriptInterface
    public void openNotifSettings() {
        act.runOnUiThread(() -> {
            try {
                Intent i;
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    i = new Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS);
                    i.putExtra(android.provider.Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, new android.content.ComponentName(act, BankListener.class).flattenToString());
                } else i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                act.startActivity(i);
            } catch (Exception e) {
                try { act.startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); } catch (Exception e2) { act.toast("설정 화면을 열 수 없어요"); }
            }
        });
    }

    @JavascriptInterface
    public void openBatterySettings() {
        act.runOnUiThread(() -> {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + act.getPackageName()));
                act.startActivity(i);
            } catch (Exception e) {
                try { act.startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception e2) { act.toast("설정 화면을 열 수 없어요"); }
            }
        });
    }

    @JavascriptInterface
    public void scanNow() {
        new Thread(() -> {
            int n = Auto.scanCalls(act);
            act.toast(n > 0 ? "통화 녹음 " + n + "건 보냈어요" : "새로 보낼 통화 녹음이 없어요");
        }).start();
    }

    @JavascriptInterface
    public String takeAuth() { return act.takeAuth(); }

    @JavascriptInterface
    public void openExternal(String url) {
        act.runOnUiThread(() -> act.openExternal(Uri.parse(url)));
    }

    // 연락처 앱의 "새 연락처" 화면을 이름·전화·주소가 채워진 채로 열기 → 사용자는 저장만 누르면 돼요
    @JavascriptInterface
    public void saveContact(String name, String phone, String address, String email) {
        act.runOnUiThread(() -> {
            try {
                Intent i = new Intent(ContactsContract.Intents.Insert.ACTION);
                i.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                if (name != null && !name.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.NAME, name);
                if (phone != null && !phone.isEmpty()) {
                    i.putExtra(ContactsContract.Intents.Insert.PHONE, phone);
                    i.putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
                }
                if (address != null && !address.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.POSTAL, address);
                if (email != null && !email.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.EMAIL, email);
                i.putExtra("finishActivityOnSaveCompleted", true);
                act.startActivity(i);
            } catch (Exception e) {
                act.toast("연락처 앱을 열 수 없어요: " + e.getMessage());
            }
        });
    }

    // 폰 연락처 전체 읽기 → window.__pcmCb(cbId, json)
    @JavascriptInterface
    public void getContacts(String cbId) {
        act.runOnUiThread(() -> act.withContactsPermission(cbId));
    }

    // 오늘 받은 은행 문자 읽기 (문자함 SMS + 긴 문자 MMS) → window.__pcmCb(cbId, json)
    @JavascriptInterface
    public void readBankSms(String cbId) {
        act.runOnUiThread(() -> act.withSmsPermission(cbId));
    }

    static final java.util.regex.Pattern BANK_NO = java.util.regex.Pattern.compile("15882100|15999000|0623846080");
    static final java.util.regex.Pattern BANK_TXT = java.util.regex.Pattern.compile("(농협|NH|새마을|MG|페퍼)");
    static final java.util.regex.Pattern MONEY = java.util.regex.Pattern.compile("(입금|출금)");
    static boolean isBank(String from, String body) {
        String d = from == null ? "" : from.replaceAll("\\D", "");
        if (BANK_NO.matcher(d).find()) return true;
        return body != null && BANK_TXT.matcher(body).find() && MONEY.matcher(body).find();
    }

    void readSms(String cbId) {
        new Thread(() -> {
            try {
                java.util.Calendar cal = java.util.Calendar.getInstance();
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0);
                long start = cal.getTimeInMillis();
                ContentResolver cr = act.getContentResolver();
                JSONArray arr = new JSONArray();
                // 짧은 문자 (SMS)
                try (Cursor c = cr.query(Uri.parse("content://sms/inbox"), new String[]{"_id", "address", "body", "date"}, "date >= ?", new String[]{String.valueOf(start)}, "date DESC")) {
                    if (c != null) while (c.moveToNext()) {
                        String from = c.getString(1), body = c.getString(2);
                        if (!isBank(from, body)) continue;
                        JSONObject o = new JSONObject();
                        o.put("id", "sms:" + c.getLong(0)); o.put("from", from == null ? "" : from); o.put("text", body == null ? "" : body); o.put("ts", c.getLong(3));
                        arr.put(o);
                    }
                }
                // 긴 문자 (LMS/MMS) — 날짜가 초 단위
                try (Cursor m = cr.query(Uri.parse("content://mms/inbox"), new String[]{"_id", "date"}, "date >= ?", new String[]{String.valueOf(start / 1000)}, "date DESC")) {
                    if (m != null) while (m.moveToNext()) {
                        long id = m.getLong(0);
                        String body = mmsText(cr, id), from = mmsFrom(cr, id);
                        if (!isBank(from, body)) continue;
                        JSONObject o = new JSONObject();
                        o.put("id", "mms:" + id); o.put("from", from); o.put("text", body); o.put("ts", m.getLong(1) * 1000);
                        arr.put(o);
                    }
                }
                JSONObject res = new JSONObject();
                res.put("list", arr);
                reply(cbId, res.toString());
            } catch (Exception e) {
                reply(cbId, "{\"error\":" + JSONObject.quote("문자 읽기 실패: " + e.getMessage()) + "}");
            }
        }).start();
    }

    static String mmsText(ContentResolver cr, long id) {
        StringBuilder sb = new StringBuilder();
        try (Cursor p = cr.query(Uri.parse("content://mms/part"), new String[]{"_id", "ct", "_data", "text"}, "mid=?", new String[]{String.valueOf(id)}, null)) {
            if (p != null) while (p.moveToNext()) {
                if (!"text/plain".equals(p.getString(1))) continue;
                String data = p.getString(2);
                if (data != null) {
                    try (java.io.InputStream in = cr.openInputStream(Uri.parse("content://mms/part/" + p.getLong(0)))) {
                        if (in != null) sb.append(Auto.readAll(in));
                    } catch (Exception ignored) { }
                } else if (p.getString(3) != null) sb.append(p.getString(3));
            }
        } catch (Exception ignored) { }
        return sb.toString();
    }

    static String mmsFrom(ContentResolver cr, long id) {
        try (Cursor a = cr.query(Uri.parse("content://mms/" + id + "/addr"), new String[]{"address"}, "type=137", null, null)) {
            if (a != null && a.moveToFirst()) return a.getString(0) == null ? "" : a.getString(0);
        } catch (Exception ignored) { }
        return "";
    }

    void readContacts(String cbId) {
        new Thread(() -> {
            try {
                ContentResolver cr = act.getContentResolver();
                Map<Long, JSONObject> map = new LinkedHashMap<>();
                String[] proj = {ContactsContract.Data.CONTACT_ID, ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.MIMETYPE, ContactsContract.Data.DATA1};
                String sel = ContactsContract.Data.MIMETYPE + " IN (?,?,?,?)";
                String[] args = {
                        ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE};
                try (Cursor c = cr.query(ContactsContract.Data.CONTENT_URI, proj, sel, args, ContactsContract.Data.DISPLAY_NAME + " ASC")) {
                    if (c != null) {
                        while (c.moveToNext()) {
                            long id = c.getLong(0);
                            String name = c.getString(1);
                            String mime = c.getString(2);
                            String val = c.getString(3);
                            if (val == null || val.isEmpty()) continue;
                            JSONObject o = map.get(id);
                            if (o == null) {
                                o = new JSONObject();
                                o.put("name", name == null ? "" : name);
                                o.put("tels", new JSONArray());
                                o.put("addr", "");
                                o.put("email", "");
                                o.put("company", "");
                                map.put(id, o);
                            }
                            if (ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE.equals(mime)) o.getJSONArray("tels").put(val);
                            else if (ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE.equals(mime)) { if (o.getString("addr").isEmpty()) o.put("addr", val.replace('\n', ' ')); }
                            else if (ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE.equals(mime)) { if (o.getString("email").isEmpty()) o.put("email", val); }
                            else if (ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE.equals(mime)) { if (o.getString("company").isEmpty()) o.put("company", val); }
                        }
                    }
                }
                JSONArray arr = new JSONArray();
                for (JSONObject o : map.values()) arr.put(o);
                JSONObject res = new JSONObject();
                res.put("list", arr);
                reply(cbId, res.toString());
            } catch (Exception e) {
                reply(cbId, "{\"error\":" + JSONObject.quote("연락처 읽기 실패: " + e.getMessage()) + "}");
            }
        }).start();
    }

    void reply(String cbId, String json) {
        act.runJs("window.__pcmCb && window.__pcmCb(" + JSONObject.quote(cbId) + "," + JSONObject.quote(json) + ")");
    }

    static String safeName(String n) {
        String s = (n == null || n.isEmpty()) ? "file" : n.replaceAll("[\\\\/:*?\"<>|]", "_");
        return s;
    }

    // 파일 공유 (카톡 · 문자 · 메일 등 공유창)
    @JavascriptInterface
    public void shareFile(String b64, String mime, String name, String text) {
        try {
            File dir = new File(act.getCacheDir(), "share");
            dir.mkdirs();
            File f = new File(dir, safeName(name));
            try (OutputStream os = new FileOutputStream(f)) { os.write(Base64.decode(b64, Base64.DEFAULT)); }
            Uri uri = FileProvider.getUriForFile(act, MainActivity.AUTHORITY, f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            i.putExtra(Intent.EXTRA_STREAM, uri);
            if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "보내기");
            act.runOnUiThread(() -> act.startActivity(ch));
        } catch (Exception e) {
            act.toast("공유 실패: " + e.getMessage());
        }
    }

    // 파일 저장 → 폰의 Download/(하위폴더) · 저장된 위치를 돌려줌
    @JavascriptInterface
    public String saveFile(String b64, String mime, String name, String subdir) {
        try {
            String rel = Environment.DIRECTORY_DOWNLOADS + ((subdir == null || subdir.isEmpty()) ? "" : "/" + safeName(subdir));
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(name));
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
            Uri uri = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("저장 위치를 만들 수 없어요");
            try (OutputStream os = act.getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new Exception("파일을 열 수 없어요");
                os.write(Base64.decode(b64, Base64.DEFAULT));
            }
            return rel.replace(Environment.DIRECTORY_DOWNLOADS, "다운로드") + "/" + safeName(name);
        } catch (Exception e) {
            act.toast("저장 실패: " + e.getMessage());
            return "";
        }
    }

    // 인쇄 · PDF 저장 (안드로이드 인쇄 화면)
    @JavascriptInterface
    public void print(String html, String title) {
        act.runOnUiThread(() -> {
            WebView pv = new WebView(act);
            printView = pv;
            pv.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    view.postDelayed(() -> {
                        PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                        String t = (title == null || title.isEmpty()) ? "PC마스터" : title;
                        PrintDocumentAdapter ad = view.createPrintDocumentAdapter(t);
                        pm.print(t, ad, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    }, 500);
                }
            });
            pv.getSettings().setJavaScriptEnabled(false);
            pv.loadDataWithBaseURL(MainActivity.HOME, html, "text/html", "utf-8", null);
        });
    }
}
