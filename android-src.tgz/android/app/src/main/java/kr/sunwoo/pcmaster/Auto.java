package kr.sunwoo.pcmaster;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

// Tasker 대신 앱이 직접: 통화 녹음 → 변환 서버 / 은행 문자 알림 → 서버
public class Auto {
    static final String SERVER = "https://pcmaster-stt.sunwoo-computer.workers.dev";
    static final int JOB_TRIGGER = 7001;
    static final int JOB_PERIODIC = 7002;
    static final Pattern CALL_PATH = Pattern.compile("(?i)(call|통화)");

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("pcm_auto", Context.MODE_PRIVATE); }
    static String key(Context c) { return prefs(c).getString("key", ""); }

    static synchronized void log(Context c, String msg) {
        String t = new SimpleDateFormat("MM/dd HH:mm", Locale.KOREA).format(new Date());
        String old = prefs(c).getString("log", "");
        String line = t + "  " + msg;
        String all = line + (old.isEmpty() ? "" : "\n" + old);
        String[] lines = all.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, 30); i++) { if (i > 0) sb.append('\n'); sb.append(lines[i]); }
        prefs(c).edit().putString("log", sb.toString()).apply();
    }

    // 새 녹음 파일이 생기면 깨우는 작업 + 15분마다 확인하는 작업 등록
    static void schedule(Context c) {
        try {
            if (prefs(c).getLong("since", 0) == 0) prefs(c).edit().putLong("since", System.currentTimeMillis() / 1000 - 120).apply();
            JobScheduler js = c.getSystemService(JobScheduler.class);
            ComponentName cn = new ComponentName(c, CallJob.class);
            JobInfo trig = new JobInfo.Builder(JOB_TRIGGER, cn)
                    .addTriggerContentUri(new JobInfo.TriggerContentUri(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS))
                    .addTriggerContentUri(new JobInfo.TriggerContentUri(MediaStore.Files.getContentUri("external"), JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS))
                    .setTriggerContentUpdateDelay(6000)
                    .setTriggerContentMaxDelay(30000)
                    .build();
            js.schedule(trig);
            if (js.getPendingJob(JOB_PERIODIC) == null) {
                JobInfo per = new JobInfo.Builder(JOB_PERIODIC, cn)
                        .setPeriodic(15 * 60 * 1000L)
                        .setPersisted(true)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                        .build();
                js.schedule(per);
            }
        } catch (Exception e) {
            log(c, "예약 실패: " + e.getMessage());
        }
    }

    static boolean hasAudioPermission(Context c) {
        String p = android.os.Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : "android.permission.READ_EXTERNAL_STORAGE";
        return c.checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    // 최근 통화 녹음 중 아직 안 보낸 것 보내기
    static synchronized int scanCalls(Context c) {
        if (key(c).isEmpty() || !hasAudioPermission(c)) return 0;
        SharedPreferences sp = prefs(c);
        long since = sp.getLong("since", System.currentTimeMillis() / 1000 - 120);
        long floor = Math.max(since, System.currentTimeMillis() / 1000 - 6 * 3600);
        Set<String> sent = new HashSet<>(sp.getStringSet("sent", new HashSet<>()));
        int n = 0;
        String[] proj = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH,
                MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.IS_PENDING};
        Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        try (Cursor cur = c.getContentResolver().query(base, proj, MediaStore.MediaColumns.DATE_ADDED + " > ?", new String[]{String.valueOf(floor)}, MediaStore.MediaColumns.DATE_ADDED + " ASC")) {
            if (cur == null) return 0;
            long now = System.currentTimeMillis() / 1000;
            while (cur.moveToNext()) {
                long id = cur.getLong(0);
                String name = cur.getString(1) == null ? "" : cur.getString(1);
                String rel = cur.getString(2) == null ? "" : cur.getString(2);
                long mod = cur.getLong(4);
                long size = cur.getLong(5);
                int pending = cur.getInt(6);
                String sid = String.valueOf(id);
                if (sent.contains(sid)) continue;
                if (!CALL_PATH.matcher(rel + "/" + name).find()) continue;
                if (pending != 0 || size < 2000) continue;
                if (now - mod < 4) continue; // 아직 쓰는 중
                Uri u = ContentUris.withAppendedId(base, id);
                if (upload(c, u, name)) {
                    sent.add(sid);
                    n++;
                    log(c, "통화 녹음 보냄: " + name);
                }
            }
        } catch (Exception e) {
            log(c, "녹음 확인 실패: " + e.getMessage());
        }
        // 오래된 기록 정리
        if (sent.size() > 300) { Set<String> keep = new HashSet<>(); int i = 0; for (String s : sent) { if (i++ > 150) keep.add(s); } sent = keep; }
        sp.edit().putStringSet("sent", sent).apply();
        return n;
    }

    static boolean upload(Context c, Uri u, String name) {
        HttpURLConnection con = null;
        try {
            String q = "/?key=" + URLEncoder.encode(key(c), "UTF-8") + "&file=" + URLEncoder.encode(name, "UTF-8");
            con = (HttpURLConnection) new URL(SERVER + q).openConnection();
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setConnectTimeout(20000);
            con.setReadTimeout(120000);
            con.setChunkedStreamingMode(64 * 1024);
            con.setRequestProperty("Content-Type", "application/octet-stream");
            try (InputStream in = c.getContentResolver().openInputStream(u); OutputStream out = con.getOutputStream()) {
                if (in == null) return false;
                byte[] buf = new byte[64 * 1024];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            }
            int code = con.getResponseCode();
            if (code != 200) log(c, "녹음 전송 실패 (" + code + "): " + name);
            return code == 200;
        } catch (Exception e) {
            log(c, "녹음 전송 오류: " + e.getMessage());
            return false;
        } finally {
            if (con != null) con.disconnect();
        }
    }

    static boolean postSms(Context c, String from, String body) {
        HttpURLConnection con = null;
        try {
            String q = "/sms?key=" + URLEncoder.encode(key(c), "UTF-8") + "&from=" + URLEncoder.encode(from, "UTF-8");
            con = (HttpURLConnection) new URL(SERVER + q).openConnection();
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setConnectTimeout(15000);
            con.setReadTimeout(30000);
            con.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            try (OutputStream out = con.getOutputStream()) { out.write(body.getBytes(StandardCharsets.UTF_8)); }
            int code = con.getResponseCode();
            log(c, code == 200 ? "은행 문자 보냄: " + from : "문자 전송 실패 (" + code + ")");
            return code == 200;
        } catch (Exception e) {
            log(c, "문자 전송 오류: " + e.getMessage());
            return false;
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
