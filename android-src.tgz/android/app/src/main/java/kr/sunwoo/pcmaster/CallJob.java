package kr.sunwoo.pcmaster;

import android.app.job.JobParameters;
import android.app.job.JobService;

// 새 녹음 파일이 생기면(또는 15분마다) 깨어나서 통화 녹음을 보냄
public class CallJob extends JobService {
    @Override
    public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try { Auto.scanCalls(getApplicationContext()); }
            finally {
                jobFinished(params, false);
                if (params.getJobId() == Auto.JOB_TRIGGER) Auto.schedule(getApplicationContext());
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) { return true; }
}
