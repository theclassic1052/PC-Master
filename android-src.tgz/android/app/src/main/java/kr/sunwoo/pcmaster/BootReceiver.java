package kr.sunwoo.pcmaster;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

// 폰을 다시 켜거나 앱을 업데이트해도 자동 전송을 다시 켬
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) { Auto.schedule(c); }
}
